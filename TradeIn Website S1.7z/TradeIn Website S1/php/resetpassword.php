<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Reset Password</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <header>
        <nav>
            <section class="logo">
                <img src="../images/trade-in-logo.png" alt="Trade-In logo" height="100px" width="200px">
            </section>
            <section class="navBar">
                <a class="navElement" href="../index.html">Home</a>
                <a class="navElement" href="../pages/contact.html">Contact</a>
                <a class="navElement" href="../pages/about.html">About</a>
                <a class="navElement" href="./login.php">Account</a>
            </section>
        </nav>
    </header>
<?php
    require('db.php');
	session_start();
	$username = $_SESSION ['username'];
    
    if (isset($_REQUEST['username'])) {
		
		$queryget = mysql_query("SELECT password FROM users WHERE username ='$username'");
		$row=mysql_fetch_assoc($queryget);
		$oldpassworddb=$row['password'];
		
        $oldpassword = stripslashes($_REQUEST['oldpassword']);
        $oldpassword = mysqli_real_escape_string($con, $oldpassword);
		$oldpassword = md5($oldpassword);
		
        $newpassword = stripslashes($_REQUEST['newpassword']);
        $newpassword = mysqli_real_escape_string($con, $newpassword);
		
        $newpasswordrepeat = stripslashes($_REQUEST['newpasswordrepeat']);
        $newpasswordrepeat = mysqli_real_escape_string($con, $newpasswordrepeat);
		
		if($oldpassworddb == $oldpassword){
			if($newpassword == $newpasswordrepeat){
        
        $query = "UPDATE users SET password = 'md5($newpassword)' WHERE username = '$username'";
                     
        $result = mysqli_query($con, $query);
        if ($result) {
            echo "<div class='form'>
                  <h3>Password updated successfully.</h3><br/>
                  <p class='link'>Click here to <a href='login.php'>Login</a></p>
                  </div>";
        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='resetpassword.php'>Reset Password</a> again.</p>
                  </div>";
        }}}
    } else {
?>
    <form class="form" action="" method="post">
        <h1 class="login-title">Reset Password</h1>
        <input type="password" class="login-input" name="oldpassword" placeholder="Old Password" required />
        <input type="password" class="login-input" name="newpassword" placeholder="New Password">
        <input type="password" class="login-input" name="newpasswordrepeat" placeholder="Repeat New Password">
        <input type="submit" name="submit" value="Reset Password" class="login-button">
        <p class="link"><a href="../pages/userHomepage.html">Cancel</a></p>
    </form>
<?php
    }
	
?>
        <section class="backButtonBox">
            <a class="backToHomepage" href="../pages/userHomepage.html">Back to Homepage</a>
        </section>
</body>
</html>