function getResponse() {
	// Get text input from user
    let query = document.getElementById('userq').value
	$("#userq").val(null);
	
	// Spans are added to Query and Answer to design the chat bubble
    $("#elem").append('<p class="query"><span>' + query + '</span></p>');
	
	// Convert to lower case to avoid confusion
    query = query.toLowerCase();
	
	// Intentional slight delay to Bot Reply
    setTimeout(() => {
        let botResponse = getReply(query);
		$("#elem").append('<p class="answer"><span>' + botResponse + '</span></p>');
    }, 750)
}



function getReply(q) {

    // Hello Goodbye
    if (q == "hi" || q == "hello" || q == "hey") {
        return "Hi!";}
		
	else if (q == "hallo") {
		return "Mein Deutsch ist nicht so toll!";}
		
	else if (q == "goodbye" || q == "bye" || q == "see ya") {
		return "I'll be here and waiting to help!";}	
	
	// General Account
	let x = q.includes("account");
	if (x == true){
		return "Click <a href='https://www.w3schools.com/html/html_links.asp'>here</a> for account help.";} 
	
	// Password
	x = q.includes("password");
	if (x == true){
		return "Want to change your password?\n Reset your password by logging in and pressing the 'Account' button!</a>";} 
	
	// Do You Work
	x = q.includes("do you work");
	if (x == true){
		return "Yes I do!";} 
	
	
	// Stocks
	x = q.includes("stocks");
	y = q.includes("general");
	if (x == true || y == true){
		return "Click <a href='https://www.nasdaq.com/articles/the-most-frequently-asked-questions-about-the-stock-market-in-2022'>here</a> for some general info on stocks today!";} 
	
	// Empty
	if (q == "") {
        return "Try typing something!";}
		
	
	
	else {
        return "I'm afraid I dont understand.";
    }
}