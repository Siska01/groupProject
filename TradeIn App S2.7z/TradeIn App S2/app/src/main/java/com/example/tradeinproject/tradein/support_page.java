package com.example.tradeinproject.tradein;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.tradeinproject.R;

public class support_page extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageButton call_button = findViewById(R.id.phone_button);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support_page);


    }
}