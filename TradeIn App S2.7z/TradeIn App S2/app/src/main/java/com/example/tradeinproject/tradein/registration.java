package com.example.tradeinproject.tradein;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tradeinproject.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class registration extends AppCompatActivity {
    Button register_button;
    EditText email, password, reenter_password;
    FirebaseAuth Authentication;
    FirebaseUser User;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Authentication = FirebaseAuth.getInstance();
        User = Authentication.getCurrentUser();
        register_button = (Button) findViewById(R.id.register_button);
        email = (EditText) findViewById(R.id.registration_email);
        password = (EditText) findViewById(R.id.registration_password);
        reenter_password = (EditText) findViewById(R.id.re_enter_password_registration);
        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });
    }
    private void openLogin(){
        Intent login_intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(login_intent);

    }
    private void register(){
        String input_email = email.getText().toString();
        String input_password= password.getText().toString();
        String input_reenter_password = reenter_password.getText().toString();

        if(input_email.isEmpty())
            email.setError("Enter a valid email!");
        if (input_password.isEmpty())
            password.setError("Enter a valid password!");
        else if(!input_password.matches(input_reenter_password))
            reenter_password.setError("Passwords do not match!");
        else
            Authentication.createUserWithEmailAndPassword(input_email,input_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), "Successful Registration", Toast.LENGTH_SHORT).show();
                        openLogin();
                    }
                    else
                        Toast.makeText(getApplicationContext(),"" + task.getException(),Toast.LENGTH_SHORT).show();
                }
            });
    }

}