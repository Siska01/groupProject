package com.example.tradeinproject.tradein;

import java.util.List;

public interface cart_listener {
    void load_products_cart(List<shopping_cart_model> cart_modelList);
    void failed_product_load_cart(String error_message);
}
