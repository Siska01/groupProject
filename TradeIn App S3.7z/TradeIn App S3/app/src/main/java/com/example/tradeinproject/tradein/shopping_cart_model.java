package com.example.tradeinproject.tradein;

public class shopping_cart_model {
    private String product_name,product_price,product_image,product_key;
    private int product_quantity;
    private float cart_total_price;

    public shopping_cart_model(){}

    public float getCart_total_price() {
        return cart_total_price;
    }

    public void setCart_total_price(float cart_total_price) {
        this.cart_total_price = cart_total_price;
    }

    public void setProduct_quantity(int product_quantity) {
        this.product_quantity = product_quantity;
    }

    public String getProduct_key() {
        return product_key;
    }

    public Integer getProduct_quantity() {
        return product_quantity;
    }

    public void setProduct_quantity(Integer product_quantity) {
        this.product_quantity = product_quantity;
    }

    public void setProduct_key(String product_key) {
        this.product_key = product_key;
    }

    public String getProduct_image() {
        return product_image;
    }

    public void setProduct_image(String product_image) {
        this.product_image = product_image;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }
}
