package com.example.tradeinproject.tradein;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.tradeinproject.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.regex.PatternSyntaxException;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    Button login_button, register_button;
    FirebaseAuth Authentication;
    FirebaseUser User;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = (EditText) findViewById(R.id.login_email_address);
        password = (EditText) findViewById(R.id.login_password);
        login_button = (Button) findViewById(R.id.login_button);
        register_button = (Button) findViewById(R.id.login_register_button);
        Authentication = FirebaseAuth.getInstance();
        User = Authentication.getCurrentUser();
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent register_intent = new Intent(getApplicationContext(), registration.class);
                startActivity(register_intent);
            }
        });
    }

    private void login() {
            String input_email = email.getText().toString();
            String input_password= password.getText().toString();
            if(input_email.isEmpty())
                email.setError("Enter a valid email!");
            if (input_password.isEmpty())
                password.setError("Enter a valid password!");
            else
                Authentication.signInWithEmailAndPassword(input_email,input_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @SuppressLint("SuspiciousIndentation")
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                            openAccount();
                        }
                        else Toast.makeText(getApplicationContext(),"" + task.getException(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void openAccount(){
        Intent account_intent = new Intent(getApplicationContext(),Account.class);
        startActivity(account_intent);
    }
}

