package com.example.tradeinproject.tradein;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tradeinproject.R;

import java.util.ArrayList;



public class product_adapter extends RecyclerView.Adapter<recycler_card_view_holder> {
    ArrayList<products_model> productsModels;
    Context card_context;

    public product_adapter(Context context,ArrayList<products_model> productsModels) {
        this.productsModels = productsModels;
        this.card_context = context;
    }

    public Context get_product_card_context() {
        return card_context;
    }

    public void set_product_card_context(Context product_card_context) {
        this.card_context= product_card_context;
    }

    @NonNull
    @Override
    public recycler_card_view_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View card_view_view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_card,null);
        return new recycler_card_view_holder(card_view_view);
    }

    @Override
    public void onBindViewHolder(@NonNull recycler_card_view_holder holder,int position) {
        holder.view_holder_title.setText(productsModels.get(position).getProduct_name());
        holder.view_holder_description.setText(new StringBuilder("$").append(productsModels.get(position).getProduct_price()));
        holder.view_holder_image.setImageResource(productsModels.get(position).getProduct_image());
    }

    @Override
    public int getItemCount() {
        return productsModels.size();
    }
}
