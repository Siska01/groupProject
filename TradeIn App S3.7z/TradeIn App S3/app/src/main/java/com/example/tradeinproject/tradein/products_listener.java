package com.example.tradeinproject.tradein;

import java.util.List;

public interface products_listener {
    void load_products(List<products_model> products_modelList);
    void failed_product_load(String error_message);
}
