package com.example.tradeinproject.tradein;

import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tradeinproject.R;
import com.example.tradeinproject.tradein.cart_listener;
import com.example.tradeinproject.tradein.product_adapter;
import com.example.tradeinproject.tradein.products_listener;
import com.example.tradeinproject.tradein.products_model;
import com.example.tradeinproject.tradein.shopping_cart_model;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class product_page extends AppCompatActivity implements com.example.tradeinproject.tradein.products_listener, com.example.tradeinproject.tradein.cart_listener {
    RecyclerView recyclerView;
    RelativeLayout relativeLayout;
    FrameLayout frameLayout;
    product_adapter product_adapter
    products_listener products_listener;
    cart_listener cart_listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        relativeLayout = findViewById(R.id.product_page_layout);
        recyclerView = findViewById(R.id.products_recycler);
        frameLayout = findViewById(R.id.cart_layout);
        super.onCreate(savedInstanceState);
        product_adapter = new product_adapter(this,load_product_from_firebase());
        recyclerView = findViewById(R.id.stock_day_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(product_adapter);
    }

    private void load_product_from_firebase() {
        List<products_model> products_modelList = new ArrayList<>();
        FirebaseDatabase.getInstance().getReference("Stocks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot productSnapshot : snapshot.getChildren()) {
                        products_model products_model = productSnapshot.getValue(products_model.class);
                        products_model.setProduct_key(productSnapshot.getKey());
                        products_modelList.add(products_model);
                    }
                    products_listener.load_products(products_modelList);
                } else
                    products_listener.failed_product_load("Product Can't Be Found");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                products_listener.failed_product_load(error.getMessage());
            }
        });
    }


    @Override
    public void load_products(List<products_model> products_modelList) {
        product_adapter product_adapter = new product_adapter(getApplicationContext(), (ArrayList<products_model>) products_modelList);
        recyclerView.setAdapter(product_adapter);
    }

    @Override
    public void failed_product_load(String error_message) {
        Snackbar.make(relativeLayout, error_message, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void load_products_cart(List<shopping_cart_model> cart_modelList) {

    }

    @Override
    public void failed_product_load_cart(String error_message) {

    }
}
