package com.example.tradeinproject.tradein;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tradeinproject.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Account extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener {
    BottomNavigationView bottomNavigationView;
    Button financial_report_button,ai_engine_button,stock_of_the_day_button,price_alerts_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.home);
        financial_report_button = findViewById(R.id.financial_report_button);
        stock_of_the_day_button = findViewById(R.id.stock_of_the_day_button);
        price_alerts_button = findViewById(R.id.price_alerts_button);
        stock_of_the_day_button.setOnClickListener(view -> {
            Intent stock_day_intent = new Intent(getApplicationContext(),stock_day.class);
            startActivity(stock_day_intent);
        });
    }
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.home:
                Intent intent = new Intent(getApplicationContext(),Account.class);
                startActivity(intent);
            case R.id.aboutUs:
                Intent intent1 = new Intent(getApplicationContext(),support_page.class);
                startActivity(intent1);
            case R.id.contactUs:
                Intent intent2 = new Intent(getApplicationContext(),support_page.class);
                startActivity(intent2);
        }
        return false;
    }
}