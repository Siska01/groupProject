package com.example.tradeinproject.tradein;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tradeinproject.R;
import com.example.tradeinproject.tradein.recycler_card_view_adapter;
import com.example.tradeinproject.tradein.recycler_card_view_model;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;

public class stock_day extends AppCompatActivity {
    RecyclerView recyclerView;
    recycler_card_view_adapter view_adapter;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock_day);
        int day = 0;
        view_adapter = new recycler_card_view_adapter(get_card_models(), this);
        recyclerView = findViewById(R.id.stock_day_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(view_adapter);
        LocalDate localDate = null;
        localDate = LocalDate.now();
        DayOfWeek dayOfWeek = null;
        dayOfWeek = DayOfWeek.from(localDate);
        day = dayOfWeek.getValue();


    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private ArrayList<recycler_card_view_model>get_card_models(){
        LocalDate localDate = null;
        int day = 0;
        localDate = LocalDate.now();
        DayOfWeek dayOfWeek = null;
        dayOfWeek = DayOfWeek.from(localDate);
        day = dayOfWeek.getValue();
        ArrayList<recycler_card_view_model> card_models = new ArrayList<>();
        recycler_card_view_model model = new recycler_card_view_model();
        String amazoninfo = getString(R.string.amazon);
        String spotifyinfo = getString(R.string.spotify);
        String disneyinfo = getString(R.string.disney);
        String paramountinfo = getString(R.string.paramount);
        String gmeinfo = getString(R.string.gme);
        String amcinfo = getString(R.string.amc);
        String teslainfo = getString(R.string.tesla);
        if (day == 1){
            model = new recycler_card_view_model();
            model.setCard_title("Amazon");
            model.setCard_description(amazoninfo);
            model.setCard_image(R.drawable.amazon);
            card_models.add(model);
        }

        if (day == 2){
            model = new recycler_card_view_model();
            model.setCard_title("Spotify");
            model.setCard_description(spotifyinfo);
            model.setCard_image(R.drawable.spotify);
            card_models.add(model);
        }

        if (day == 6){
            model = new recycler_card_view_model();
            model.setCard_title("Disney");
            model.setCard_description(disneyinfo);
            model.setCard_image(R.drawable.disney);
            card_models.add(model);
        }

        if (day == 4){
            model = new recycler_card_view_model();
            model.setCard_title("Paramount");
            model.setCard_description(paramountinfo);
            model.setCard_image(R.drawable.paramount);
            card_models.add(model);
        }

        if (day == 5){
            model = new recycler_card_view_model();
            model.setCard_title("GameStop");
            model.setCard_description(gmeinfo);
            model.setCard_image(R.drawable.gamestop);
            card_models.add(model);
        }

        if (day == 3){
            model = new recycler_card_view_model();
            model.setCard_title("AMC");
            model.setCard_description(amcinfo);
            model.setCard_image(R.drawable.amc);
            card_models.add(model);
        }

        if (day == 7){
            model = new recycler_card_view_model();
            model.setCard_title("Tesla");
            model.setCard_description(teslainfo);
            model.setCard_image(R.drawable.tesla);
            card_models.add(model);
        }

        return card_models;
    }
}