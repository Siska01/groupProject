package com.example.tradein;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class price_alerts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price_alerts);
    }
}