package com.example.tradeinproject.tradein;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tradeinproject.R;

import java.util.ArrayList;

public class recycler_card_view_adapter extends RecyclerView.Adapter<recycler_card_view_holder> {
        ArrayList<recycler_card_view_model> card_models;
        Context card_context;
        public recycler_card_view_adapter(ArrayList<recycler_card_view_model> card_models,Context context) {
            this.card_models = card_models;
            this.card_context = context;
        }

        public Context getCard_view_context() {
            return card_context;
        }

        public void setCard_view_context(Context card_view_context) {
            this.card_context = card_view_context;
        }

        @NonNull
        @Override
        public recycler_card_view_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View card_view_view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view,null);
            return new recycler_card_view_holder(card_view_view);
        }

        @Override
        public void onBindViewHolder(@NonNull recycler_card_view_holder holder,int position) {
            holder.view_holder_title.setText(card_models.get(position).getCard_title());
            holder.view_holder_description.setText(card_models.get(position).getCard_description());
            holder.view_holder_image.setImageResource(card_models.get(position).getCard_image());
        }
        @Override
        public int getItemCount() {
            return card_models.size();
        }
    }

