package com.example.tradeinproject.tradein;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tradeinproject.R;


public class recycler_card_view_holder extends RecyclerView.ViewHolder {
    ImageView view_holder_image;
    TextView view_holder_title, view_holder_description;

    recycler_card_view_holder(@NonNull View itemView) {
        super(itemView);
        this.view_holder_image = itemView.findViewById(R.id.card_image);
        this.view_holder_title = itemView.findViewById(R.id.card_title);
        this.view_holder_description = itemView.findViewById(R.id.card_description);
    }
}

